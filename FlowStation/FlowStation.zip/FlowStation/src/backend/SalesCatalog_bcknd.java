package backend;

import dbConnections.Connections;
import java.sql.*;

public class SalesCatalog_bcknd {

}
