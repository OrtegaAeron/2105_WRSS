/**
 * 
 */
/**
 * 
 */
module FlowStation {
	requires java.desktop;
	requires java.sql;

}